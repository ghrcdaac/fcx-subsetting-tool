from .schema import Schema, SchemaOpts

__version__ = "0.24.0"
__all__ = ("Schema", "SchemaOpts")
